const agentTemplates = [
  { name: 'Project Analyst', role: 'planner', title: 'Analyze request and define scope', description: 'Extract the goal, audience, constraints, deliverables, and acceptance criteria.' },
  { name: 'Brand & Research Agent', role: 'research', title: 'Research audience and positioning', description: 'Identify target audiences, competitors to research, differentiators, and brand voice.' },
  { name: 'Website Builder Agent', role: 'website', title: 'Plan website and conversion flow', description: 'Define pages, mobile behavior, accessibility, forms, and conversion goals.' },
  { name: 'SEO / GEO / AEO Agent', role: 'seo', title: 'Create search visibility plan', description: 'Plan technical SEO, keyword clusters, local SEO, structured data, and answer-engine content.' },
  { name: 'Creative Studio Agent', role: 'creative', title: 'Create creative production briefs', description: 'Prepare platform-specific image/video creative briefs while preserving supplied product details.' },
  { name: 'Social Distribution Agent', role: 'social', title: 'Build channel content calendar', description: 'Plan channel-specific posts, hooks, captions, formats, and suggested posting windows.' },
  { name: 'Growth & Lead Agent', role: 'growth', title: 'Plan lead generation and campaigns', description: 'Define lead magnets, landing page CTAs, campaign experiments, and budget guardrails.' },
  { name: 'QA & Compliance Agent', role: 'qa', title: 'Review quality, risk, and approvals', description: 'Check consistency, mobile readiness, claims, privacy, accessibility, and approval gates.' }
];

export function buildPlan(prompt, projectName = 'New project') {
  const cleanPrompt = String(prompt || '').trim();
  const lower = cleanPrompt.toLowerCase();
  const tasks = agentTemplates.map((a, i) => ({
    id: `task_${i + 1}`,
    agent: a.name,
    role: a.role,
    title: a.title,
    description: a.description,
    status: 'queued',
    priority: i === 0 || i === 7 ? 'high' : 'normal',
    requiresApproval: ['social', 'growth'].includes(a.role),
    output: null
  }));
  const deliverables = [];
  if (/website|web site|store|shopify|landing page|site/.test(lower)) deliverables.push('Website structure and conversion-ready page plan');
  if (/seo|geo|aeo|google|search/.test(lower)) deliverables.push('SEO/GEO/AEO implementation checklist');
  if (/social|instagram|facebook|tiktok|youtube|content|post/.test(lower)) deliverables.push('Platform-specific content calendar and creative briefs');
  if (/ad|advert|campaign|marketing/.test(lower)) deliverables.push('Marketing campaign plan with approval gates');
  if (/brand|logo|identity/.test(lower)) deliverables.push('Brand positioning and identity brief');
  if (!deliverables.length) deliverables.push('Project plan, requirements, quality checklist, and next actions');
  return {
    projectName: String(projectName || 'New project').slice(0, 120),
    summary: cleanPrompt.slice(0, 700),
    languageDetected: /[\u0600-\u06FF]/.test(cleanPrompt) ? 'Urdu/Arabic script likely' : /\b(mujy|mujhe|k liye|bana do|kar do|hai)\b/i.test(cleanPrompt) ? 'Roman Urdu/Hindi likely' : 'English or mixed',
    deliverables,
    acceptanceCriteria: ['Requirements and assumptions are recorded', 'Mobile-first quality is included', 'SEO and accessibility are reviewed where relevant', 'External actions remain approval-gated', 'Final outputs include a clear QA checklist'],
    tasks,
    safety: { externalPublishing: 'approval_required', adSpend: 'approval_required', purchases: 'approval_required', bulkOutreach: 'approval_required', deployment: 'approval_required' }
  };
}

export async function createPlan(prompt, projectName, env = process.env) {
  const fallback = buildPlan(prompt, projectName);
  if (!env.AI_API_KEY) return { ...fallback, planningMode: 'rules-based fallback', aiNote: 'AI_API_KEY is not configured. Plan was created with the built-in planner.' };
  const base = (env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  try {
    const response = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${env.AI_API_KEY}` },
      body: JSON.stringify({
        model: env.AI_MODEL || 'gpt-4o-mini',
        temperature: 0.2,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: 'You are a careful business project planner. Return JSON with keys projectName, summary, deliverables (array of strings), acceptanceCriteria (array of strings), risks (array of strings), recommendedAgents (array of strings). Do not claim to perform external actions. Never request secrets. All publishing, ad spend, purchases, deployments, and bulk outreach require human approval.' },
          { role: 'user', content: `Project name: ${projectName || 'New project'}\nUser request: ${String(prompt).slice(0, 10000)}` }
        ]
      }),
      signal: AbortSignal.timeout(25000)
    });
    if (!response.ok) throw new Error(`AI provider returned HTTP ${response.status}`);
    const data = await response.json();
    const raw = data?.choices?.[0]?.message?.content;
    const ai = JSON.parse(raw);
    return { ...fallback, ...ai, projectName: String(ai.projectName || fallback.projectName).slice(0, 120), tasks: fallback.tasks, safety: fallback.safety, planningMode: 'AI-assisted', aiNote: 'AI-assisted plan created. Review outputs before execution.' };
  } catch (err) {
    return { ...fallback, planningMode: 'rules-based fallback', aiNote: `AI planning unavailable (${String(err.message).slice(0, 140)}). A fallback plan was created.` };
  }
}
