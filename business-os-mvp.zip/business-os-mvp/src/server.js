import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPlan } from './planner.js';
import { listProjects, getProject, createProject, listApprovals, decideApproval, getStats, listAuditLogs } from './store.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '127.0.0.1';
const mime = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml', '.json':'application/json; charset=utf-8' };
function send(res, status, body) { res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' }); res.end(JSON.stringify(body)); }
async function body(req) { let raw=''; for await (const chunk of req) { raw += chunk; if (raw.length > 1_000_000) throw new Error('Request body too large'); } return raw ? JSON.parse(raw) : {}; }
function safeText(value, max=10000) { return typeof value === 'string' ? value.trim().slice(0,max) : ''; }
const server = http.createServer(async (req,res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/api/health') return send(res,200,{ok:true,service:'Business OS MVP',aiConfigured:Boolean(process.env.AI_API_KEY),mode:'local-starter',externalActionsEnabled:false});
    if (req.method === 'GET' && url.pathname === '/api/stats') return send(res,200,getStats());
    if (req.method === 'GET' && url.pathname === '/api/projects') return send(res,200,{projects:listProjects()});
    if (req.method === 'GET' && url.pathname.startsWith('/api/projects/')) { const project = getProject(url.pathname.split('/')[3]); return project ? send(res,200,{project}) : send(res,404,{error:'Project not found'}); }
    if (req.method === 'POST' && url.pathname === '/api/projects') {
      const input = await body(req); const prompt = safeText(input.prompt,10000); const name = safeText(input.name,120);
      if (prompt.length < 8) return send(res,400,{error:'Please enter a project request of at least 8 characters.'});
      const plan = await createPlan(prompt,name || 'New project');
      const project = createProject(plan,prompt);
      return send(res,201,{project});
    }
    if (req.method === 'GET' && url.pathname === '/api/approvals') return send(res,200,{approvals:listApprovals()});
    if (req.method === 'POST' && url.pathname.startsWith('/api/approvals/')) {
      const approvalId = url.pathname.split('/')[3]; const input = await body(req); const decision = input.decision;
      try { const approval = decideApproval(approvalId,decision,safeText(input.note,500)); return approval ? send(res,200,{approval}) : send(res,404,{error:'Approval not found'}); }
      catch (e) { return send(res,409,{error:e.message}); }
    }
    if (req.method === 'GET' && url.pathname === '/api/audit') return send(res,200,{events:listAuditLogs()});
    if (url.pathname.startsWith('/api/')) return send(res,404,{error:'API route not found'});
    const requested = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
    const file = path.resolve(root, `.${requested}`);
    if (!file.startsWith(root + path.sep) && file !== path.join(root,'index.html')) return send(res,403,{error:'Forbidden'});
    fs.readFile(file,(err,data) => { if (err) { res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'}); res.end('Not found'); return; } res.writeHead(200,{'Content-Type':mime[path.extname(file)] || 'application/octet-stream','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'"}); res.end(data); });
  } catch (err) { send(res,400,{error:err instanceof SyntaxError ? 'Invalid JSON body' : String(err.message || 'Request failed')}); }
});
server.listen(port,host,() => console.log(`Business OS MVP running at http://${host}:${port}`));
