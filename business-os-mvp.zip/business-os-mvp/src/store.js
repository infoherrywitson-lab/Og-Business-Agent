import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dataDir = path.resolve('data');
const dbPath = path.join(dataDir, 'db.json');
const empty = { projects: [], approvals: [], auditLogs: [] };
function ensure() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify(empty, null, 2));
}
function read() { ensure(); try { return JSON.parse(fs.readFileSync(dbPath, 'utf8')); } catch { return structuredClone(empty); } }
function write(db) { ensure(); const tmp = `${dbPath}.tmp`; fs.writeFileSync(tmp, JSON.stringify(db, null, 2)); fs.renameSync(tmp, dbPath); }
function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }
function audit(db, action, entityId, detail = {}) { db.auditLogs.unshift({ id: id('audit'), action, entityId, detail, createdAt: new Date().toISOString() }); db.auditLogs = db.auditLogs.slice(0, 500); }

export function listProjects() { return read().projects.sort((a,b) => b.createdAt.localeCompare(a.createdAt)); }
export function getProject(projectId) { return read().projects.find(p => p.id === projectId) || null; }
export function createProject(plan, prompt) {
  const db = read();
  const now = new Date().toISOString();
  const project = { id: id('proj'), name: plan.projectName || 'New project', prompt, plan, status: 'planning', createdAt: now, updatedAt: now };
  project.tasks = (plan.tasks || []).map(t => ({ ...t, id: `${project.id}_${t.id}`, projectId: project.id, createdAt: now, updatedAt: now }));
  db.projects.push(project);
  for (const t of project.tasks.filter(t => t.requiresApproval)) {
    const approval = { id: id('approval'), projectId: project.id, taskId: t.id, title: `Approve execution: ${t.title}`, description: 'Approval is a record only; no external publishing or spending is performed by this starter.', status: 'pending', createdAt: now, decidedAt: null };
    db.approvals.push(approval);
  }
  audit(db, 'project.created', project.id, { name: project.name, taskCount: project.tasks.length });
  write(db);
  return project;
}
export function listApprovals() { return read().approvals.sort((a,b) => b.createdAt.localeCompare(a.createdAt)); }
export function decideApproval(approvalId, decision, note = '') {
  if (!['approved', 'rejected'].includes(decision)) throw new Error('Invalid decision');
  const db = read(); const item = db.approvals.find(a => a.id === approvalId);
  if (!item) return null;
  if (item.status !== 'pending') throw new Error('Approval has already been decided');
  item.status = decision; item.note = String(note).slice(0, 500); item.decidedAt = new Date().toISOString();
  audit(db, `approval.${decision}`, item.id, { projectId: item.projectId, note: item.note });
  write(db); return item;
}
export function getStats() {
  const db = read();
  const projects = db.projects;
  return { projects: projects.length, tasks: projects.reduce((n,p) => n + p.tasks.length, 0), pendingApprovals: db.approvals.filter(a => a.status === 'pending').length, completedTasks: projects.reduce((n,p) => n + p.tasks.filter(t => t.status === 'completed').length, 0), auditEvents: db.auditLogs.length };
}
export function listAuditLogs() { return read().auditLogs.slice(0, 100); }
