import test from 'node:test';
import assert from 'node:assert/strict';
import { buildPlan } from '../src/planner.js';

test('buildPlan creates task plan and approval gates', () => {
  const plan = buildPlan('Build a website, SEO and social marketing for Fusion Kids', 'Fusion Kids');
  assert.equal(plan.projectName, 'Fusion Kids');
  assert.ok(plan.tasks.length >= 7);
  assert.ok(plan.tasks.some(t => t.role === 'seo'));
  assert.ok(plan.tasks.filter(t => t.requiresApproval).length >= 1);
  assert.equal(plan.safety.adSpend, 'approval_required');
});

test('buildPlan handles Roman Urdu brief', () => {
  const plan = buildPlan('Mujhy meri brand k liye website bana do');
  assert.equal(plan.languageDetected, 'Roman Urdu/Hindi likely');
  assert.ok(plan.deliverables.some(d => d.toLowerCase().includes('website')));
});
